//
//  PrivacyRightsCollectionViewCell.m
//  HouseHuaBang
//
//  Created by it on 2019/12/16.
//  Copyright © 2019 房趣科技. All rights reserved.
//

#import "PrivacyRightsCollectionViewCell.h"

@implementation PrivacyRightsCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.layer.cornerRadius = 4;
    self.layer.shadowColor = [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:0.15].CGColor;
    self.layer.shadowOffset = CGSizeMake(0,0);
    self.layer.shadowOpacity = 1;
    self.layer.shadowRadius = 10;
}

@end
