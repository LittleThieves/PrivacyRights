//
//  PrivacyRightsViewController.m
//  NewHouseBao
//
//  Created by it on 2019/11/8.
//  Copyright © 2019 apple. All rights reserved.
//

#import "PrivacyRightsViewController.h"

#import "PrivacyRightsCollectionViewCell.h"//权限项目cell
#import "PrivacySubView.h"

@interface PrivacyRightsViewController ()<UITextViewDelegate,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource>

///权限列表
@property (weak, nonatomic) IBOutlet UICollectionView *collView;
///富文本显示控件
@property (weak, nonatomic) IBOutlet UITextView *textV;
///不同意按钮
@property (weak, nonatomic) IBOutlet UIButton *disagreeBtn;
///同意按钮
@property (weak, nonatomic) IBOutlet UIButton *agreeBtn;
///高度约束
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *textVHeightConst;
///权限项目数据源
@property (nonatomic, strong) NSMutableArray *dataSou;
///隐私协议的地址
@property (nonatomic, copy) NSString *ysUrlStr;

@end

@implementation PrivacyRightsViewController
#pragma mark ================ 懒加载 ================
- (NSMutableArray *)dataSou {
    if (!_dataSou) {
        _dataSou = [NSMutableArray arrayWithArray:@[
        @{@"title":@"摄像头（相机）权限", @"content":@"当用户在App内修改头像等功能时，如需使用相机拍照时，向用户申请", @"selected":@YES},
        @{@"title":@"位置信息", @"content":@"申请该权限用于获取用户所在城市，为用户提供当前城市的房源", @"selected":@YES},
        @{@"title":@"语音（麦克风）权限", @"content":@"如在App中使用语音通信功能与经纪人或客服联系，我们将使用该权限", @"selected":@YES},
        @{@"title":@"相册权限", @"content":@"如您需要更换头像或者在投诉建议中提交图片信息时需要使用该权限", @"selected":@YES},
        @{@"title":@"通知", @"content":@"我们会及时为你关注的房源、小区等相关价格变动", @"selected":@YES},
        ]];
    }
    return _dataSou;
}

#pragma mark ================ 系统生命周期 ================
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.disagreeBtn.layer.cornerRadius = 4.f;
    self.disagreeBtn.layer.masksToBounds = YES;
    self.agreeBtn.layer.cornerRadius = 4.f;
    self.agreeBtn.layer.masksToBounds = YES;

    self.agreeBtn.superview.layer.shadowColor = CCCUIColorFromHexAlpha(0x000000, 0.1).CGColor;
    self.agreeBtn.superview.layer.shadowOffset = CGSizeMake(0,-2);
    self.agreeBtn.superview.layer.shadowOpacity = 1;
    self.agreeBtn.superview.layer.shadowRadius = 4;
    
    //初始化collview
    self.collView.delegate = self;
    self.collView.dataSource = self;
    //注册cell
    [self.collView registerNib:[UINib nibWithNibName:@"PrivacyRightsCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"PrivacyRightsCollectionViewCell"];
    //初始化textview
    self.textV.editable = NO;//必须禁止输入，否则点击将弹出输入键盘
    self.textV.delegate = self;
    self.textV.scrollEnabled = NO;
    //去除左右边距
    self.textV.textContainer.lineFragmentPadding = 0.0;
    //设置垂直居中
    self.textV.textContainerInset = UIEdgeInsetsMake(0, 0, 0, 0);
    
    //配置隐私政策
    NSString *str1 = @"您也可以在系统中关闭授权，或进入APP内设置、删除、修改个人信息，以上操作可能影响到部分功能的正常使用。烦请使用APP前请阅读并同意";
    NSString *str2 = @"《豪世华邦隐私政策》";
    NSString *str = [NSString stringWithFormat:@"%@%@",str1,str2];
    NSRange range1 = [str rangeOfString:str1];
    NSRange range2 = [str rangeOfString:str2];
    NSMutableAttributedString *mastring = [[NSMutableAttributedString alloc] initWithString:str attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:12.f]}];
    [mastring addAttribute:NSForegroundColorAttributeName value:[AppStyleConfiguration wenzi666666Color] range:range1];
    [mastring addAttribute:NSForegroundColorAttributeName value:[AppStyleConfiguration selectedBGColor] range:range2];
    // 1.必须要用前缀（privacy），随便写但是要有
    // 2.要有后面的方法，如果含有中文，url会无效，所以转码
    self.ysUrlStr = @"http://m.hshb.com/hz/h5/agree/_hshb/hshb_yinsi.htm";
    NSString *valueString1 = [[NSString stringWithFormat:@"privacy://%@",self.ysUrlStr] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
    [mastring addAttribute:NSLinkAttributeName value:valueString1 range:range2];
    self.textV.linkTextAttributes = @{};//NSForegroundColorAttributeName:[AppStyleConfiguration selectedBGColor]
    NSString *valueString3 = [[NSString stringWithFormat:@"secondPerson://%@",@"无效"] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
    [mastring addAttribute:NSLinkAttributeName value:valueString3 range:range1];
    
    self.textV.attributedText = mastring;
    //计算内容高度
    CGFloat itemH = [MyControl heightForString:str CGSizeMake:kMainScreen_width-30 font:12.f]+1;
    self.textVHeightConst.constant = itemH;
}

#pragma mark ================ 同意回调 ================
- (IBAction)clickAgreeBtn:(id)sender {
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"privacyRightsvc"];
    [self.view removeFromSuperview];
    [self removeFromParentViewController];
    [[RootBoard shareRootBoard] viewDidLoad];
}

#pragma mark ================ 点击不同意回调 ================
- (IBAction)clickdisagreeBtn:(UIButton *)sender {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"是否确定不继续使用APP内的所有功能?" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"确定不同意" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        abort();//退出APP
    }];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"再想想" style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:cancelAction];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark ================ UICollectionView代理方法 ================
// 分区中item元素个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataSou.count;
}

// 注册单元格
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    PrivacyRightsCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PrivacyRightsCollectionViewCell" forIndexPath:indexPath];
    NSDictionary *itemDic = self.dataSou[indexPath.item];
    cell.titleLab.text = itemDic[@"title"];
    cell.contentLab.text = itemDic[@"content"];
    cell.imgV.highlighted = NO;
    if ([itemDic[@"selected"] boolValue]) {
        cell.imgV.highlighted = [itemDic[@"selected"] boolValue];
    }
    
    return cell;
}

//7、单独定制itme视图size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *itemDic = self.dataSou[indexPath.item];
    CGFloat itemH = [MyControl heightForString:itemDic[@"content"] CGSizeMake:kMainScreen_width-90 font:12.f]+45+1;
    return CGSizeMake(kMainScreen_width-30, itemH);
}
// 单元格点击事件
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *itemDic = self.dataSou[indexPath.item];
    NSNumber *highlighted = [NSNumber numberWithBool:![itemDic[@"selected"] boolValue]];
    NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:itemDic];
    [mutableItem setValue:highlighted forKey:@"selected"];
    self.dataSou[indexPath.item] = mutableItem;
    [collectionView reloadData];//刷新UI
}
#pragma mark ================ UITextViewDelegate ================
- (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange {

    if ([[URL scheme] isEqualToString:@"privacy"]) {
        PrivacySubView *pv = [[NSBundle mainBundle] loadNibNamed:@"PrivacySubView" owner:self options:nil].firstObject;
        pv.pathUrl = self.ysUrlStr;
        [self.view addSubview:pv];
        [pv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(0));
            make.left.equalTo(@(0));
            make.bottom.equalTo(@(0));
            make.right.equalTo(@(0));
        }];
        return NO;
    }else if ([[URL scheme] isEqualToString:@"secondPerson"]) {
//        NSString *titleString = [NSString stringWithFormat:@"你点击了第二个文字:%@",[URL host]];
//        [self clickLinkTitle:titleString];
        return NO;
    }
   
    return YES;
}

#pragma mark ================ 打开《隐私政策》 ================
- (void)clickLinkTitle:(NSString *)title {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:title preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleCancel handler:nil];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark ================ 释放内存 ================
- (void)dealloc {
    NSLog(@"释放了 === %@",[self class]);
}

@end
