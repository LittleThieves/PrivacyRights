//
//  PrivacySubView.m
//  NewHouseBao
//
//  Created by it on 2019/11/8.
//  Copyright © 2019 apple. All rights reserved.
//

#import "PrivacySubView.h"

#import "IMYWebView.h"

@interface PrivacySubView ()<IMYWebViewDelegate>

@property(nonatomic, strong)IMYWebView *WKwebView;

@property (weak, nonatomic) IBOutlet UIView *topV;

@end

@implementation PrivacySubView


- (void)setPathUrl:(NSString *)pathUrl {
    _pathUrl = pathUrl;
    self.WKwebView = [[IMYWebView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height - 64) usingUIWebView:NO];
    self.WKwebView.delegate = self;
    self.WKwebView.scalesPageToFit = YES;
    NSURL *url = [NSURL URLWithString:self.pathUrl];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.WKwebView loadRequest:request];
    [self addSubview:_WKwebView];
    WeakSelf(self);
    [self.WKwebView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.topV.mas_bottom).offset(0);
        make.left.equalTo(@(0));
        make.bottom.equalTo(weakself.mas_bottom).offset(-kMainBottomSpaceHeight);
        make.right.equalTo(@(0));
    }];
}


- (IBAction)backVC:(id)sender {
    [UIView animateWithDuration:1 animations:^{
        [self removeFromSuperview];
    }];
}

#pragma mark ================ IMYWebViewDelegate ================
- (void)webViewDidStartLoad:(IMYWebView *)webView {
    [SVProgressHUD showWithStatus:@"正在加载"];
}

- (void)webViewDidFinishLoad:(IMYWebView *)webView {
    [SVProgressHUD dismiss];
}
//获取url
- (BOOL)webView:(IMYWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {

    return YES;
}

#pragma mark ================ 释放内存 ================
- (void)dealloc {
    NSLog(@"释放了 === %@",[self class]);
}

@end
