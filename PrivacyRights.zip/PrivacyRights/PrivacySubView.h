//
//  PrivacySubView.h
//  NewHouseBao
//
//  Created by it on 2019/11/8.
//  Copyright © 2019 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PrivacySubView : UIView

@property (nonatomic, copy) NSString *pathUrl;


@end

NS_ASSUME_NONNULL_END
