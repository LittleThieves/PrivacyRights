//
//  PrivacyRightsCollectionViewCell.h
//  HouseHuaBang
//
//  Created by it on 2019/12/16.
//  Copyright © 2019 房趣科技. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PrivacyRightsCollectionViewCell : UICollectionViewCell
///选择状态
@property (weak, nonatomic) IBOutlet UIImageView *imgV;
///标题
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
///内容
@property (weak, nonatomic) IBOutlet UILabel *contentLab;

@end

NS_ASSUME_NONNULL_END
